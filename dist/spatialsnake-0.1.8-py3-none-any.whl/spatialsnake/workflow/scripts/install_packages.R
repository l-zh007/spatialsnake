# ===================================
# 0. 准备：安装基础工具
# ===================================
if (!require("remotes", quietly = TRUE))
  install.packages("remotes")

if (!require("BiocManager", quietly = TRUE))
  install.packages("BiocManager")

# ===================================
# 1. CRAN 包（一步安装）
# ===================================
install.packages(c(
  "optparse",
  "tidyverse",       # 包含 ggplot2, dplyr, tidyr, tibble, forcats 等
  "RColorBrewer",
  "patchwork",
  "cowplot",
  "pheatmap",
  "Seurat"
), dependencies = TRUE)

# ===================================
# 2. Bioconductor 包
# ===================================
BiocManager::install(c(
  "ComplexHeatmap",
  "clusterProfiler",
  "edgeR",
  "org.Hs.eg.db",
  "org.Mm.eg.db"
), ask = FALSE)

# ===================================
# 3. GitHub 包
# ===================================
options(timeout = 600)    # 避免大包下载超时

# schard: h5ad / Seurat 互转
remotes::install_github("cellgeni/schard")

# spacexr: RCTD 反卷积
remotes::install_github("dmcable/spacexr", build_vignettes = FALSE)

# CellChat: 细胞通讯分析  (你环境当前为 v1.6.1，用 jinworks/CellChat)
remotes::install_github("jinworks/CellChat")

# ggsankey: 桑基图
remotes::install_github("davidsjoberg/ggsankey")