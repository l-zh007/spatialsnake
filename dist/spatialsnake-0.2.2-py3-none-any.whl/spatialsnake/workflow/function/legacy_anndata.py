import warnings
import re
from typing import TYPE_CHECKING

import numpy as np
from spatialdata import (
    SpatialData,
    get_centroids,
    get_extent,
    join_spatialelement_table,
    to_circles,
)
from spatialdata._core.operations._utils import transform_to_data_extent
from spatialdata.models import Image2DModel, ShapesModel, TableModel, get_table_keys
from spatialdata.transformations import Identity, Scale

from anndata import AnnData


def _compute_if_needed(obj):
    return obj.compute() if hasattr(obj, "compute") else obj


def _infer_xy_columns(df) -> tuple[str, str]:
    preferred_pairs = [
        ("x", "y"),
        ("center_x", "center_y"),
        ("coord_x", "coord_y"),
        ("imagecol", "imagerow"),
    ]
    for x_col, y_col in preferred_pairs:
        if x_col in df.columns and y_col in df.columns:
            return x_col, y_col

    numeric_columns = list(df.select_dtypes(include=[np.number]).columns)
    if len(numeric_columns) >= 2:
        return numeric_columns[0], numeric_columns[1]
    raise ValueError("Unable to infer spatial coordinate columns from the points element.")


def _align_points_to_table(table: AnnData, points_element, instance_key: str) -> np.ndarray:
    points_df = _compute_if_needed(points_element).copy()
    if hasattr(points_df.index, "astype"):
        points_df.index = points_df.index.astype(str)

    x_col, y_col = _infer_xy_columns(points_df)
    obs = table.obs.copy()
    obs.index = obs.index.astype(str)

    if instance_key in obs.columns:
        instance_ids = obs[instance_key].astype(str)
        if instance_ids.isin(points_df.index).all():
            aligned = points_df.loc[instance_ids]
            return aligned[[x_col, y_col]].to_numpy(dtype=np.float32)

        if instance_key in points_df.columns:
            lookup = points_df.copy()
            lookup[instance_key] = lookup[instance_key].astype(str)
            aligned = (
                obs[[instance_key]]
                .merge(
                    lookup[[instance_key, x_col, y_col]],
                    on=instance_key,
                    how="left",
                    sort=False,
                )
            )
            if aligned[[x_col, y_col]].isna().any().any():
                raise ValueError("Failed to align points coordinates to the table using the instance key.")
            return aligned[[x_col, y_col]].to_numpy(dtype=np.float32)

    if obs.index.isin(points_df.index).all():
        aligned = points_df.loc[obs.index]
        return aligned[[x_col, y_col]].to_numpy(dtype=np.float32)

    raise ValueError("Failed to align points coordinates to the table rows.")


def _image_to_hwc(image) -> np.ndarray:
    data = image.data if hasattr(image, "data") else image
    data = _compute_if_needed(data)
    arr = np.asarray(data)
    dims = tuple(getattr(image, "dims", ()))

    if arr.ndim == 2:
        return arr[:, :, None]
    if arr.ndim != 3:
        raise ValueError(f"Unsupported image array ndim: {arr.ndim}")

    if dims and all(dim in dims for dim in ("y", "x", "c")):
        axes = [dims.index("y"), dims.index("x"), dims.index("c")]
        return np.transpose(arr, axes)
    if dims and all(dim in dims for dim in ("c", "y", "x")):
        return np.transpose(arr, (1, 2, 0))
    if arr.shape[0] <= 4 and arr.shape[1] > 4 and arr.shape[2] > 4:
        return np.transpose(arr, (1, 2, 0))
    return arr


def _downscale_image(arr: np.ndarray, target_max_side: int) -> tuple[np.ndarray, float]:
    height, width = arr.shape[:2]
    longest_side = max(height, width)
    if longest_side <= target_max_side:
        return arr, 1.0

    scale = target_max_side / float(longest_side)
    target_height = max(1, int(round(height * scale)))
    target_width = max(1, int(round(width * scale)))
    y_idx = np.linspace(0, height - 1, target_height).astype(int)
    x_idx = np.linspace(0, width - 1, target_width).astype(int)
    return arr[y_idx][:, x_idx, ...], scale


def _infer_spot_diameter(adata: AnnData, coords: np.ndarray) -> float:
    bin_name = adata.uns.get("bin_name")
    if isinstance(bin_name, str):
        match = re.search(r"bin(\d+)", bin_name)
        if match is not None:
            return float(match.group(1))

    resolution = adata.uns.get("resolution")
    if isinstance(resolution, (int, float, np.integer, np.floating)) and float(resolution) > 0:
        return float(resolution)

    if coords.shape[0] > 1:
        diffs_x = np.diff(np.unique(coords[:, 0]))
        diffs_y = np.diff(np.unique(coords[:, 1]))
        positive_diffs = np.concatenate([diffs_x[diffs_x > 0], diffs_y[diffs_y > 0]])
        if len(positive_diffs) > 0:
            return float(np.min(positive_diffs))
    return 1.0


def _legacy_points_table_to_anndata(
    sdata: SpatialData,
    table_name: str,
    region_name: str,
    instance_key: str,
    coordinate_system: str,
    include_images: bool,
    downscaled_hires_length: int,
    downscaled_lowres_length: int,
) -> AnnData:
    print("[to_legacy_anndata] using points fallback")
    table = sdata[table_name]
    points_element = sdata[region_name]
    adata = table.copy()
    coords = _align_points_to_table(table, points_element, instance_key)
    spot_diameter_fullres = _infer_spot_diameter(adata, coords)

    adata.obsm["spatial"] = coords

    if include_images and len(sdata.images) > 0:
        adata.uns.setdefault("spatial", {})
        hires_scale_for_coords = None
        for image_name, image in sdata.images.items():
            try:
                arr = _image_to_hwc(image)
                hires_img, hires_scale = _downscale_image(arr, downscaled_hires_length)
                lowres_img, lowres_scale = _downscale_image(arr, downscaled_lowres_length)
                adata.uns["spatial"][image_name] = {
                    "images": {
                        "hires": hires_img,
                        "lowres": lowres_img,
                    },
                    "scalefactors": {
                        "tissue_hires_scalef": hires_scale,
                        "tissue_lowres_scalef": lowres_scale,
                        "spot_diameter_fullres": spot_diameter_fullres,
                    },
                    "metadata": {
                        "source_coordinate_system": coordinate_system,
                        "fallback_from_points": True,
                    },
                }
                if hires_scale_for_coords is None:
                    hires_scale_for_coords = hires_scale
            except Exception as e:
                print(f"[to_legacy_anndata] failed to export image {image_name}: {e}")

        if hires_scale_for_coords is not None:
            adata.obsm["spatial"] = (coords * hires_scale_for_coords).astype(np.float32)

    print(f"[to_legacy_anndata] fallback obsm['spatial'] shape={adata.obsm['spatial'].shape}")
    print(f"[to_legacy_anndata] fallback uns['spatial'] keys={list(adata.uns.get('spatial', {}).keys())}")
    return adata



def transform_to_zarr(adata: AnnData,sample_id: str) -> SpatialData:
    """Convert (legacy) spatial AnnData object to SpatialData object.
    
     revise from  https://github.com/scverse/spatialdata-io/blob/main/src/spatialdata_io/converters/legacy_anndata.py
     Add revice some data to match spatialsnake pipeline
    """
    SPATIAL = "spatial"

    SCALEFACTORS = "scalefactors"
    TISSUE_HIRES_SCALEF = "tissue_hires_scalef"
    TISSUE_LOWRES_SCALEF = "tissue_lowres_scalef"
    SPOT_DIAMETER_FULLRES = "spot_diameter_fullres"

    IMAGES = "images"
    HIRES = "hires"
    LOWRES = "lowres"

    # SpatialData keys
    REGION = sample_id
    REGION_KEY = "region"
    INSTANCE_KEY = "cell_id"
    SPOT_DIAMETER_FULLRES_DEFAULT = 10

    images = {}
    shapes = {}
    spot_diameter_fullres_list = []
    shapes_transformations = {}

    if SPATIAL in adata.uns:
        dataset_ids = list(adata.uns[SPATIAL].keys())
        for dataset_id in dataset_ids:
            # read the image data and the scale factors for the shapes
            keys = set(adata.uns[SPATIAL][dataset_id].keys())
            tissue_hires_scalef = None
            tissue_lowres_scalef = None
            hires = None
            lowres = None
            if SCALEFACTORS in keys:
                scalefactors = adata.uns[SPATIAL][dataset_id][SCALEFACTORS]
                if TISSUE_HIRES_SCALEF in scalefactors:
                    tissue_hires_scalef = scalefactors[TISSUE_HIRES_SCALEF]
                if TISSUE_LOWRES_SCALEF in scalefactors:
                    tissue_lowres_scalef = scalefactors[TISSUE_LOWRES_SCALEF]
                if SPOT_DIAMETER_FULLRES in scalefactors:
                    spot_diameter_fullres_list.append(scalefactors[SPOT_DIAMETER_FULLRES])
            if IMAGES in keys:
                image_data = adata.uns[SPATIAL][dataset_id][IMAGES]
                if HIRES in image_data:
                    hires = image_data[HIRES]
                if LOWRES in image_data:
                    lowres = image_data[LOWRES]

            # construct the spatialdata elements
            if hires is not None:
                if 'hires_image' in dataset_id:
                  image_index=f"{dataset_id}"
                else:
                  image_index=f"{dataset_id}_hires_image"
                # prepare the hires image
                assert tissue_hires_scalef is not None, (
                    "tissue_hires_scalef is required when an the hires image is present"
                )
                hires_image = Image2DModel.parse(
                    hires, dims=("y", "x", "c"), transformations={f"{image_index}": Identity()}
                )
                images[image_index] = hires_image

                # prepare the transformation to the hires image for the shapes
                scale_hires = Scale([tissue_hires_scalef, tissue_hires_scalef], axes=("x", "y"))
                shapes_transformations[image_index] = scale_hires
            if lowres is not None:
                if 'hires_image' in dataset_id:
                  image_index=f"{dataset_id}"
                else:
                  image_index=f"{dataset_id}_lowres_image"
                assert tissue_lowres_scalef is not None, (
                    "tissue_lowres_scalef is required when an the lowres image is present"
                )
                lowres_image = Image2DModel.parse(
                    lowres, dims=("y", "x", "c"), transformations={f"{image_index}": Identity()}
                )
                images[image_index] = lowres_image

                # prepare the transformation to the lowres image for the shapes
                scale_lowres = Scale([tissue_lowres_scalef, tissue_lowres_scalef], axes=("x", "y"))
                shapes_transformations[image_index] = scale_lowres

    # validate the spot_diameter_fullres value
    if len(spot_diameter_fullres_list) > 0:
        d = np.array(spot_diameter_fullres_list)
        if not np.allclose(d, d[0]):
            warnings.warn(
                "spot_diameter_fullres is not constant across datasets. Using the average value.",
                UserWarning,
                stacklevel=2,
            )
            spot_diameter_fullres = d.mean()
        else:
            spot_diameter_fullres = d[0]
    else:
        warnings.warn(
            f"spot_diameter_fullres is not present. Using {SPOT_DIAMETER_FULLRES_DEFAULT} as default value.",
            UserWarning,
            stacklevel=2,
        )
        spot_diameter_fullres = SPOT_DIAMETER_FULLRES_DEFAULT

    # parse and prepare the shapes
    if SPATIAL in adata.obsm:
        xy = adata.obsm[SPATIAL]
        radius = spot_diameter_fullres / 2
        shapes[REGION] = ShapesModel.parse(xy, geometry=0, radius=radius, transformations=shapes_transformations)
        # link the shapes to the table
        adata.obs['cell_id'] = adata.obs.index
        new_table = adata.copy()
        if TableModel.ATTRS_KEY in new_table.uns:
            del new_table.uns[TableModel.ATTRS_KEY]
        new_table.obs[REGION_KEY] = REGION
        new_table.obs[REGION_KEY] = new_table.obs[REGION_KEY].astype("category")
        new_table.obs[INSTANCE_KEY] = shapes[REGION].index.values
        new_table = TableModel.parse(new_table, region=REGION, region_key=REGION_KEY, instance_key=INSTANCE_KEY)
    else:
        new_table = adata.copy()
    return SpatialData(tables={"table": new_table}, images=images, shapes=shapes)

def to_legacy_anndata(
    sdata: SpatialData,
    coordinate_system: str | None = None,
    table_name: str | None = None,
    include_images: bool = False,
) -> AnnData:
    print("[to_legacy_anndata] start")
    print(f"[to_legacy_anndata] include_images={include_images}")
    """Convert a SpatialData object to a (legacy) spatial AnnData object.

    This is useful for using packages expecting spatial information in AnnData, for example Scanpy and older versions
    of Squidpy. Using this format for any new package is not recommended.

    This function by default ignores images (recommended); setting the `include_images` parameter to `True` will
    include a downscaled version of the images in the output AnnData object.

    Parameters
    ----------
    sdata
        SpatialData object
    coordinate_system
        The coordinate system to consider. The AnnData object will be populated with the data transformed to this
        coordinate system.
    table_name
        The name of the table in the SpatialData object to consider. If None and the SpatialData object has only one
        table, that table will be used.
    include_images
        If True, includes downscaled versions of the images in the output AnnData object. It is recommended to handle
        the full resolution images separately and keep them in the SpatialData object.

    Returns
    -------
    The legacy spatial AnnData object.

    Notes
    -----
    Edge cases and limitations:

        - The Table can only annotate Shapes or Labels.
        - Labels will be approximated to circles by using the centroids of each label and an average approximated
          radius.
        - The Table cannot annotate more than one Shapes element. If multiple Shapes elements are present, please merge
          them into a single Shapes element and make the table annotate the new Shapes element.
        - Table rows not annotating geometries in the coordinate system will be dropped. Similarly, Shapes rows (in the
          case of Labels, the circle rows approximating the Labels) not annotated by Table rows will be dropped.

    How resolutions, coordinates, indices and Table rows will be affected:

        - When `include_images` is `True`, the Images will be scaled (see later) and will not maintain the original
          resolution.
        - The Shapes centroids will likely change to match the alignment in the specified coordinate system, and to the
          images bounding boxes when `include_images` is `True` (see below).
        - The Table and Shapes rows will have the same indices as before the conversion, which is useful for plugging
          results back to the SpatialData object, but as mentioned above, some rows may be dropped.

    When `include_images` is `True`, the generated AnnData object will contain low-resolution images and their origin
    will be reset to the pixel (0, 0). In particular, the ImageContainer class used by Squidpy is not used. Eventual
    transformations are applied before conversion. Precisely, this is how the Images are prepared for the AnnData
    object:

        - For each Image aligned to the specified coordinate system, the coordinate transformation to the coordinate
          system is applied; all the Images are rendered to a common target bounding box, which is the bounding box of
          the union of the Images aligned to the target coordinate system.
        - The origins of the new images will match the pixel (0, 0) of the target bounding box.
        - Each Image is downscaled (or upscaled) during rendering to fit a 2000x2000 pixels image (downscaled_hires) and
          a 600x600 pixels image (downscaled_lowres).
        - Practically the above implies that if the Images have very dissimilar locations, most the rendered Images will
          have empty spaces; in such cases it is recommended to drop or crop some images before the conversion.

    Matching of spatial coordinates and pixel coordinates:

        - When `include_images` is `True`, the coordinates in `obsm['spatial']` will match the downscaled (generated)
          image "hires" (i.e. coordinate (x, y) will match with the pixel (y, x) in the image). Please note that the
          "hires" naming is used for legacy reasons, but the image is actually downscaled and fairly low resolution.
        - The above matching is not perfect due to this bug: https://github.com/scverse/spatialdata/issues/165, which
          will eventually be addressed.

    Imperfect downscaling:

        - Due to the bug mentioned above, https://github.com/scverse/spatialdata/issues/165, when the downscaling factor
          is large, the error between the original and the downscale image can be significant. This is another reason to
          not recommend using include_images=True. Note, however, that the error can be large only between the original
          and the downscaled images, not between the downscaled images and the new spatial coordinates. Thus the use
          may be acceptable for some use cases.

    Final consideration:

        - Due to the legacy nature of the AnnData object generated, this function may not handle all the edge cases,
          please report any issue you may find.
    """
    DOWNSCALED_HIRES_LENGTH = 2000
    DOWNSCALED_LOWRES_LENGTH = 600
    # check that coordinate system is valid
    css = sdata.coordinate_systems
    if coordinate_system is None:
        assert len(css) == 1, "The SpatialData object has more than one coordinate system. Please specify one."
        coordinate_system = css[0]
        print(f"[to_legacy_anndata] coordinate_system={coordinate_system}")
    else:
        assert coordinate_system in css, (
            f"The SpatialData object does not have the coordinate system {coordinate_system}."
        )
    sdata = sdata.filter_by_coordinate_system(coordinate_system)
    print(f"[to_legacy_anndata] tables={list(sdata.tables.keys())}")
    print(f"[to_legacy_anndata] shapes={list(sdata.shapes.keys())}")
    print(f"[to_legacy_anndata] images={list(sdata.images.keys())}")

    if table_name is None:
        assert len(sdata.tables) == 1, (
            "When the table_name is not specified, the SpatialData object must have exactly one table. The specified "
            f"sdata object, after being filtered for the coordinate system {coordinate_system}, has "
            f"{len(sdata.tables)} tables."
        )
        table_name = next(iter(sdata.tables))
    else:
        assert table_name in sdata.tables, f"The table {table_name} is not present in the SpatialData object."
    print(f"[to_legacy_anndata] table_name={table_name}")

    table = sdata[table_name]
    (
        region,
        _,
        instance_key,
    ) = get_table_keys(table)
    if not isinstance(region, list):
        region = [region]
    print(f"[to_legacy_anndata] region={region}")
    print(f"[to_legacy_anndata] instance_key={instance_key}")

    # the table needs to annotate exactly one Shapes element
    if len(region) != 1:
        raise ValueError(f"The table needs to annotate exactly one element. Found {len(region)}.")
    if region[0] in sdata.points:
        return _legacy_points_table_to_anndata(
            sdata=sdata,
            table_name=table_name,
            region_name=region[0],
            instance_key=instance_key,
            coordinate_system=coordinate_system,
            include_images=include_images,
            downscaled_hires_length=DOWNSCALED_HIRES_LENGTH,
            downscaled_lowres_length=DOWNSCALED_LOWRES_LENGTH,
        )
    if region[0] not in sdata.shapes and region[0] not in sdata.labels:
        raise ValueError("The table needs to annotate a Shapes or Labels element, not Points.")
    element = sdata[region[0]]
    region_name = region[0]
    print(f"[to_legacy_anndata] region_name={region_name}")

    # convert polygons, multipolygons and labels to circles
    shapes = to_circles(element)
    circles_sdata = SpatialData(tables={table_name: table}, shapes={region_name: shapes})

    joined_elements, new_table = join_spatialelement_table(
        sdata=circles_sdata, spatial_element_names=region_name, table_name=table_name, how="inner", match_rows="left"
    )

    # the table after the filtering must not be empty
    assert len(new_table) > 0, (
        "The table does not annotate any geometry in the Shapes element. This could also be caused by a mismatch "
        "between the type of the indices of the geometries and the type of the INSTANCE_KEY column of the table."
    )
    print(f"[to_legacy_anndata] new_table_rows={len(new_table)}")

    sdata_pre_rasterize = SpatialData(
        tables={table_name: new_table}, shapes={region_name: joined_elements[region_name]}
    )

    # process the images
    downscaled_images_hires = {}
    downscaled_images_lowres = {}
    sdata_post_rasterize = None
    if not include_images:
        sdata_post_rasterize = sdata_pre_rasterize
    else:
        sdata_images = sdata.subset(element_names=list(sdata.images.keys()))
        print(f"[to_legacy_anndata] sdata_images={list(sdata_images.images.keys())}")
        for image_name, image in sdata_images.images.items():
            sdata_pre_rasterize[image_name] = image
        bb = get_extent(sdata_images, coordinate_system=coordinate_system)

        parameters_dict = {"x": "target_width", "y": "target_height", "z": "target_depth"}
        longest_side = max(bb, key=bb.get)
        parameter_hires = {parameters_dict[longest_side]: DOWNSCALED_HIRES_LENGTH}
        parameter_lowres = {parameters_dict[longest_side]: DOWNSCALED_LOWRES_LENGTH}
        downscaled_hires = transform_to_data_extent(
            sdata_pre_rasterize, coordinate_system=coordinate_system, maintain_positioning=False, **parameter_hires
        )
        downscaled_lowres = transform_to_data_extent(
            sdata_pre_rasterize, coordinate_system=coordinate_system, maintain_positioning=False, **parameter_lowres
        )
        for image_name in sdata_images.images.keys():
            downscaled_images_hires[image_name] = downscaled_hires[image_name]
            downscaled_images_lowres[image_name] = downscaled_lowres[image_name]
        print(f"[to_legacy_anndata] downscaled_images_hires={list(downscaled_images_hires.keys())}")
        print(f"[to_legacy_anndata] downscaled_images_lowres={list(downscaled_images_lowres.keys())}")

        if sdata_post_rasterize is None:
            sdata_post_rasterize = downscaled_hires

    adata = sdata_post_rasterize[table_name].copy()

    if len(downscaled_images_hires) > 0:
        for image_name in sdata_images.images.keys():
            if "spatial" not in adata.uns:
                adata.uns["spatial"] = {}
            adata.uns["spatial"][image_name] = {}
            adata.uns["spatial"][image_name]["images"] = {
                "hires": downscaled_images_hires[image_name].data.compute().transpose([1, 2, 0]),
                "lowres": downscaled_images_lowres[image_name].data.compute().transpose([1, 2, 0]),
            }
            try:
                adata.uns["spatial"][image_name]["scalefactors"] = {
                    "tissue_hires_scalef": 1.0,
                    "tissue_lowres_scalef": DOWNSCALED_LOWRES_LENGTH / DOWNSCALED_HIRES_LENGTH,
                    "spot_diameter_fullres": sdata_post_rasterize.shapes[region_name]["radius"].iloc[0] * 2,
                }
                print(f"[to_legacy_anndata] scalefactors set for {image_name}")
            except KeyError:
                print(f"[to_legacy_anndata] scalefactors missing radius for {image_name}")
                pass

    adata.obsm["spatial"] = (
        get_centroids(sdata_post_rasterize[region_name], coordinate_system=coordinate_system).compute().values
    )
    print(f"[to_legacy_anndata] obsm['spatial'] shape={adata.obsm['spatial'].shape}")
    print(f"[to_legacy_anndata] uns['spatial'] keys={list(adata.uns.get('spatial', {}).keys())}")
    print("[to_legacy_anndata] done")
    return adata



