import sys


def apply_numpy_compat():
    import numpy as np

    # PySCENIC 0.12.1 still references the removed NumPy alias `np.object`.
    if "object" not in np.__dict__:
        np.object = object  # type: ignore[attr-defined]


def main():
    if len(sys.argv) < 2:
        raise SystemExit("Usage: pyscenic_numpy_compat.py [arboreto|pyscenic] ...")

    command = sys.argv[1]
    argv = sys.argv[2:]

    apply_numpy_compat()

    if command == "arboreto":
        from pyscenic.cli.arboreto_with_multiprocessing import main as arboreto_main

        sys.argv = [sys.argv[0]] + argv
        arboreto_main()
        return

    if command == "pyscenic":
        from pyscenic.cli.pyscenic import main as pyscenic_main

        pyscenic_main(argv)
        return

    raise SystemExit(f"Unsupported command: {command}")


if __name__ == "__main__":
    main()
